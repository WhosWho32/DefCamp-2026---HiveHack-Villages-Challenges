#include <iostream>
#include <vector>
#include <strings.h>
using namespace std;

int main() {
    //Fourth question
    //In order to get the answer for this question, you have to modify some things here so that you get it printed out. Once done,
    //run the file, and you shall receive your answer.
	vector<int> encoded = {0x4d09, 0x4d23, 0x4d29, 0x4d37, 0x4d6a, 0x4d34};
    //You have to complete the XOR key. The key is merciless.
    int key = 0x;
    char decoded[7];
    decoded[0] = (char)(/*COMPLETE XOR OPERATION*/);
    decoded[1] = (char)(/*COMPLETE XOR OPERATION*/);
    decoded[2] = (char)(/*COMPLETE XOR OPERATION*/);
    decoded[3] = (char)(/*COMPLETE XOR OPERATION*/);
    decoded[4] = (char)(/*COMPLETE XOR OPERATION*/);
    decoded[5] = (char)(/*COMPLETE XOR OPERATION*/);
    decoded[6] = '\0';
    cout<<"Decoded string: "<<decoded<<"\n";
}